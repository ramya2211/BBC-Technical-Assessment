package uk.co.bbc.application

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Test
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.*
import org.junit.Rule

class TechnicalAssignmentTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

//Scenario 1 :Validate Home Page elements loaded successfully
    @Test
    fun testHomePageLoadsSuccessfully() {
        composeTestRule.onNodeWithText("My BBC").assertIsDisplayed()
        composeTestRule.onNodeWithText("Breaking News").assertIsDisplayed()
        composeTestRule.onNodeWithTag("breaking news button").assertIsDisplayed()
        composeTestRule.onNodeWithText("Politics").assertIsDisplayed()
        composeTestRule.onNodeWithTag("go to button").assertIsDisplayed()
        composeTestRule.onNodeWithText("This is a BBC app with all your favourite content").assertIsDisplayed()
        composeTestRule.onNodeWithTag("last updated").assertIsDisplayed()
    }


//Scenario 2 :Refresh & validate last updated time
    @Test
    fun testRefreshUpdatesLastUpdatedTime() {
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("refresh button").performClick()
        composeTestRule.onNodeWithContentDescription("loading spinner")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("last updated").assertIsDisplayed()
    }


//Scenario 3 :Select Technology Topic
    @Test
    fun testSelectTechnologyTopic() {
        composeTestRule.onNodeWithText("Politics").performClick()
        composeTestRule.onNodeWithText("Technology").performClick()
        composeTestRule.onNodeWithText("Technology").assertIsDisplayed()
        composeTestRule.onNodeWithTag("go to button").assertIsDisplayed()
    }


//Scenario 4 :Navigate to Technology Page
    @Test
    fun testNavigateToTechnologyPage() {
        composeTestRule.onNodeWithText("Politics").performClick()
        composeTestRule.onNodeWithText("Technology").performClick()
        composeTestRule.onNodeWithTag("go to button").performClick()
        composeTestRule.onAllNodesWithText("Technology")[1].assertIsDisplayed()
        composeTestRule.onNodeWithTag("back button").performClick()
        composeTestRule.onNodeWithText("My BBC").assertIsDisplayed()
    }


//Scenario 5 :Verify TV Guide with option No
    @Test
    fun testTVGuideNoOption() {
        composeTestRule.onNodeWithText("Politics").performClick()
        composeTestRule.onNodeWithText("TV Guide").performClick()
        composeTestRule.onNodeWithTag("go to button").performClick()
        composeTestRule.onNodeWithText("No").performClick()
        composeTestRule.onNodeWithText("My BBC").assertIsDisplayed()
    }


//Scenario 6 :Verify TV Guide with option Yes
    @Test
    fun testTVGuideYesOption() {
        composeTestRule.onNodeWithText("Politics").performClick()
        composeTestRule.onNodeWithText("TV Guide").performClick()
        composeTestRule.onNodeWithTag("go to button").performClick()
        composeTestRule.onNodeWithText("Yes").performClick()
        composeTestRule.onAllNodesWithText("TV Guide")[1].assertIsDisplayed()
        composeTestRule.onNodeWithTag("back button").performClick()
        composeTestRule.onNodeWithText("My BBC").assertIsDisplayed()
    }


//Scenario 7 :Breaking News Error Handling
    @Test
    fun testBreakingNewsErrorHandling() {
        composeTestRule.onNodeWithText("Breaking News").performClick()
        composeTestRule.onNodeWithText("Something has gone wrong").assertIsDisplayed()
        composeTestRule.onNodeWithText("Confirm").performClick()
        composeTestRule.onNodeWithText("My BBC").assertIsDisplayed()
    }
}


